const express = require("express");
const mongoose = require("mongoose");
const ejs = require('ejs')
const session = require('express-session')
const MongoDBStore = require('connect-mongodb-session')(session);
const User = require('./models/User')
var bcrypt = require('bcryptjs');
const Admin = require('./models/Admin')
const Event = require('./models/Event')
const multer = require('multer');
const Csclass = require('./models/Csclass')
const updateEventRouter = require('./routes/update'); 
const Feedback = require('./models/Feedback');




const app = express();
app.use('/', updateEventRouter);

const upload2 = multer({ dest: 'C:/Users/DELL/OneDrive/Desktop/uploads' });
;

app.use(express.static('stylees'));
app.use(express.static('Images'));
app.set('view engine', 'ejs')
app.use(express.urlencoded({ extended: true }))
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, 'uploads/') // Specify the directory where uploaded files should be stored
    },
    filename: function (req, file, cb) {
      cb(null, file.originalname) // Use the original filename for the uploaded file
    }
  })
const upload = multer({ storage: storage });



mongoose.connect('mongodb://localhost:27017/john')
    .then(() => {
        console.log("MongoDB Connected Succesfully!");
    })
    .catch((error) => {
        console.log(`${error}`);
    });

const store = new MongoDBStore({
    uri: process.env.MONGO_URI,
    collection: "mySession"
})
app.use(session({
    secret: "This is a secret",
    resave: false,
    saveUninitialized: true,
    store: store
}))

const checkAuth = (req, res, next) => {
    if (req.session.isAuthenticated) {
        next()
    } else {
        res.redirect('/signup')
    }
}
app.get('/home',(req,res) => {
    res.render('./home');
});


app.get('/signup', (req, res) => {
    res.render('register')
})

app.get('/Addevents',(req,res) => {
    res.render('Addevents')
})
app.get('/newclass',(req,res) => {
    res.render('newclass')
})



app.get('/dcseevents',(req,res) => {
    res.render('dcseevents')
})

app.get('/login', (req, res) => {
    res.render('login')
})

app.get('/csedepartment', (req, res) => {
    res.render('csedepartment')
})

app.get('/Updateevents', (req, res) => {
    const users = { date1: '2024-03-25', from1: '10:00', to1: '12:00' }; // Replace this with your actual data
    res.render('Updateevents', { users: users });
});


app.get('/csethird', (req, res) => {
    res.render('csethird'); // Renders csethird.ejs
});



app.post('/register', async(req, res) => {
    const { username, email, password } = req.body

    let user = await User.findOne({ email })
    if (user) {
        return res.redirect('/signup')
    }
    const hashedPassword = await bcrypt.hash(password, 12)

    user = new User({
        username,
        email,
        password: hashedPassword
    })
    req.session.person = user.username
    await user.save()
    res.redirect('/login')

})
app.post('/user-Feedback',async(req,res) =>{
   try{
    const{ name, email, feedback} = req.body
    const newfeedback = new Feedback({
        name:name,
        email:email,
        feedback:feedback
    });

    // Save the event to the database
    await newfeedback.save();
     // Redirect to some confirmation page or render a success message
     res.render('contact', { successMessage: 'Event added successfully!' });
     }catch (error) {
        console.error('Error saving event:', error);
        // Handle the error, maybe render an error page
        res.status(500).send('Error saving event');
    }
});

app.post('/user-login', async(req, res) => {
    const { email, password } = req.body

    const user = await User.findOne({ email })

    if (!user) {
        return res.redirect('/signup')
    }

    const checkPassword = await bcrypt.compare(password, user.password)

    if (!checkPassword) {
        return res.redirect('/signup')
    }
    req.session.isAuthicated = true
    res.redirect('/csedepartment')

})

app.post('/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) throw err;
        res.redirect('/home')
    })
});


app.get('/admindashboard', (req, res) => {
    res.render('admindashboard');
});
app.get('/Feedback', (req, res) => {
    res.render('Feedback');
});

app.get('/adminlogin',(req,res) => {

    res.render('adminlogin')
});

app.get('/About',(req,res) => {
    res.render('./About')

});
app.get('/contact',(req,res) => {
    res.render('./contact')
})
// Define a route to fetch event data
app.get('/events', async (req, res) => {
    try {
        // Retrieve event data from the database
        const eventData = await Event.find({}, '-_id associationname event date venue description from to guest eventImages');

        // Send the event data as JSON response
        res.json(eventData);
    } catch (error) {
        console.error('Error fetching event data:', error);
        res.status(500).send('Error fetching event data');
    }
});

app.get('/feedbacks',async(req,res) => {
    try{
        const feedbackdata = await Feedback.find({}, '-_id name email feedback');
        res.json(feedbackdata);

    }catch(error)
    {
        console.error('Error fetching event data:', error);
        res.status(500).send('Error fetching event data');

    }
});
app.get('/csclasses', async (req, res) => {
    try {
        const classes = await Csclass.find();
        res.json(classes);
    } catch (error) {
        console.error('Error fetching classes:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});


app.post('/admin-login', async (req, res) => {
    const { email, password } = req.body;

    // Assuming you have a separate User model for admins
    const admin = await User.findOne({ email });

    if (!admin) {
        return res.redirect('/adminlogin');
    }

    const checkPassword = await bcrypt.compare(password, admin.password);

    if (!checkPassword) {
        return res.redirect('/adminlogin');
    }

    req.session.isAdminAuthenticated = true; // Set isAdminAuthenticated to true for admin session
    res.redirect('/admindashboard'); // Redirect to admin dashboard upon successful login
});

app.get('/admindashboard', (req, res) => {
    // Check if isAdminAuthenticated is set in the session
    if (req.session.isAdminAuthenticated) {
        // If admin is authenticated, render the admin dashboard
        res.render('');
    } else {
        // If admin is not authenticated, redirect to admin login page
        res.redirect('/adminlogin');
    }
});

app.post('/admin-logout', (req, res) => {
    req.session.isAdminAuthenticated = false; // Clear isAdminAuthenticated flag
    req.session.destroy((err) => {
        if (err) {
            console.error('Error destroying session:', err);
        }
        res.redirect('/home'); // Redirect to home page after logout
    });
});

app.post('/add-event', upload.array('eventImages', 5), async (req, res) => {
    const { associationname, event, date, from, to, venue, guest, description } = req.body;

    try {
        let eventImages = [];
        if (req.files && req.files.length > 0) {
            eventImages = req.files.map(file => ({ data: file.buffer, contentType: file.mimetype }));
        }

        // Create a new event instance
        const newEvent = new Event({
            associationname: associationname,
            event: event,
            date: date,
            from: from,
            to: to,
            venue: venue,
            guest: guest,
            description: description,
            eventImages: eventImages
        });

        // Save the event to the database
        await newEvent.save();

        // Redirect to some confirmation page or render a success message
        res.render('Addevents', { successMessage: 'Event added successfully!' });
    } catch (error) {
        console.error('Error saving event:', error);
        // Handle the error, maybe render an error page
        res.status(500).send('Error saving event');
    }
});

app.post('/add-class',upload.single('references'), async (req, res) => {
    console.log('Received file:', req.file); // Log the received file

    const { date,from,to,departmentname, year, subject, faculty, status, topic, attendence,instructions } = req.body;
    const references = req.file ? req.file.path : '';
    console.log('Received file:', req.file); // Log the received file


    try {
    
        const newCsclass = new Csclass({
            date: date,
            from: from,
            to: to,
            departmentname:departmentname,
            year:year,
            subject:subject,
            faculty:faculty,
            status:status,
            topic:topic,
            references:references,
            attendence:attendence,
            instructions:instructions
        });

        // Save the event to the database
        await newCsclass.save();

        // Redirect to some confirmation page or render a success message
        res.render('newclass', { successMessage: 'Event added successfully!' });
    } catch (error) {
        console.error('Error saving event:', error);
        // Handle the error, maybe render an error page
        res.status(500).send('Error saving event');
    }
});





app.listen(7000, () => {
    console.log(`Serer started and Running 7000`);
});


