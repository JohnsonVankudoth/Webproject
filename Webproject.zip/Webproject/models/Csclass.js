const mongoose = require('mongoose');

const classSchema = new mongoose.Schema({
    date: Date,
    from: String,
    to: String,
    departmentname: String,
    year: String,
    subject:String,
    faculty: String,
    status: String,
    topic: String,
    references: String,
    attendence: String,
    instructions:String
});

const Csclass = mongoose.model('Csclass', classSchema);

module.exports = Csclass;
