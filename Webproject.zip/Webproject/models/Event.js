const mongoose = require('mongoose');

const eventSchema = new mongoose.Schema({
    associationname: String,
    event: String,
    date: Date,
    from: String,
    to: String,
    venue: String,
    guest: String,
    description: String,
    eventImages: [{ data: Buffer, contentType: String }] // Array to store multiple images
});

const Event = mongoose.model('Event', eventSchema);

module.exports = Event;
