const mongoose = require('mongoose');

const eventSchema = new mongoose.Schema({
   
    name: String,
    email:String,
    feedback:String
});

const Feedback = mongoose.model('Feedback', eventSchema);

module.exports = Feedback;