const express = require('express');
const router = express.Router();
const employcontroller = require('../controller/employeecontroller');
const employee = require('../models/Employee');

//get post put./patch ,delete

router.post('/add-emp',employcontroller.createemployee)
router.get('/allemployees',employcontroller.getemployees)
router.get('/employee/:id',employcontroller.singleemployee)
module.exports = router;