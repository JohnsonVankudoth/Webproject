const express = require('express');
const router = express.Router();
const Event = require('../models/Event');

// Route to handle event search
router.post('/search-event', async (req, res) => {
    try {
        // Destructure fields from req.body with default values
        const { associationname = '', event = '', date = '' } = req.body || {};

        // Check if any required fields are missing
        if (!associationname || !event || !date) {
            return res.status(400).json({ error: 'Missing required fields.' });
        }

        // Search for the event in the database
        const existingEvent = await Event.findOne({ associationname, event, date });

        // If the event is found, send its details as JSON response
        if (existingEvent) {
            res.status(200).json({ event: existingEvent.event, date: existingEvent.date });
        } else {
            // If the event is not found, send an error response
            res.status(404).json({ error: 'Event not found.' });
        }
    } catch (error) {
        console.error('Error searching event:', error);
        res.status(500).json({ error: 'An error occurred while searching for the event.' });
    }
});

module.exports = router;
