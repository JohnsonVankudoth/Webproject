const mongoose = require('mongoose');

const userschema = new mongoose.Schema({

    fname : {
        type:String
    },
    lname : {
        type:String
    },
    age: {
        type:Number
    },
    email:{
        type:String
    }

});

const User = mongoose.model('User',userschema)
module.exports = User
